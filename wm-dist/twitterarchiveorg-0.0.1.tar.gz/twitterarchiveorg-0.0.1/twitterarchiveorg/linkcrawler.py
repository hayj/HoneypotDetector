# coding: utf-8

from databasetools.mongo import *
from twitterarchiveorg import __version__

if __name__ == '__main__':
    
    # TODO faire un if octods...
    
    mc = MongoCollection \
        (
            "taolinks",
            "crawling",
            version=__version__,
            indexNotUniqueOn=["domain"],
            indexOn=["twitter_url"],
            user="jamy",
            password="c'est pas sorcier*",
            host="192.168.1.27",
        )
    mc.resetCollection()
    o1 = {"domain": "google.fr", "twitter_url": "http://t.co/JHgvy2hdsvfj", "html": "<html>data</html>"}
    o2 = {"domain": "google.com", "twitter_url": "http://t.co/JH2gvy2151vfj", "html": "<html>data2</html>"}
    o3 = {"domain": "google.de", "twitter_url": "http://t.co/JH5247451vfj", "html": "<html>data3</html>"}
    mc.insert([o1, o2, o3])
    
    print(mc.toDataFrame())