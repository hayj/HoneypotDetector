# coding: utf-8


########## WORSPACE IN PYTHON PATH ##########
# Include all Paths :
# TODO faire un include de tous les sous dossiers du Workspace en remontant 4 dossiers
# TODO (mettre une variable pour le nombre de dossier a remonter).
# TODO mettre aussi le changement en utf-8
# TODO Et mettre le os.chdir("??") aussi
# TODO Faire une sorte d'entete pour chaque fichier python
# Updated 09/03/17
workspaceName = "TwitterArchiveOrg" # Set the name of the Workspace in all ancestors folders
onlyInit = False # TODO
import sys
import os
import re
def dirsHasRegex(dirs, regex):
    if not isinstance(dirs, list):
        dirs = [dirs]
    # for all subdirs:
    for currentDir in dirs:
        # We get all files:
        files = getFileNames(currentDir)
        # We check if there .py or __init__.py:
        for fname in files:
            if re.search(regex, fname) is not None:
                return True
    return False

def getFileNames(currentFolder):
    files = [item for item in os.listdir(currentFolder) if os.path.isfile(os.path.join(currentFolder, item))]
    return files

def getSubdirsPaths(currentFolder):
    dirs = [currentFolder + item + "/" for item in os.listdir(currentFolder) if os.path.isdir(os.path.join(currentFolder, item))]
    return dirs

# We get the Workspace dir:
currentFolder = os.path.dirname(os.path.abspath(__file__))
workspace = currentFolder.split(workspaceName)[0] + workspaceName + "/"
# And while there are folders to watch:
penddingFolderList = [workspace]
pathsToAdd = []
while len(penddingFolderList) != 0:
    # We pop the current folder in in the pending queue:
    currentFolder = penddingFolderList.pop(0)
    if not currentFolder.split("/")[-2].startswith("."):
        hasPy = dirsHasRegex(currentFolder, ".py$")
        atLeastOneSubDirHasInit = dirsHasRegex(getSubdirsPaths(currentFolder), "__init__.py")
        # We add it in the path list:
        if hasPy or atLeastOneSubDirHasInit:
            pathsToAdd.append(currentFolder)
        # And We add the subfolders in the pending queue if there is no __init__.py:
        if not atLeastOneSubDirHasInit:
            subDirs = getSubdirsPaths(currentFolder)
            penddingFolderList += subDirs
# We add all paths in the python path:
print(pathsToAdd)
for path in pathsToAdd:
    sys.path.append(path)
#     print path
#############################################







# nn pew in twitterarchiveorg-venv python ~/wm-dist-tmp/TwitterArchiveOrg/twitterarchiveorg/unshorttao.py

from systemtools.basics import *
from datatools.json import *
from datatools.url import *
from datatools.csvreader import *
from systemtools.file import *
from systemtools.location import *
from systemtools.system import *
from systemtools.logger import *
from datatools.url import *
from datatools.newstools import *
from twitterarchiveorg.urlgenerator import *
import random
from unshortener.unshortener import *
import time


def seeUnshortenerDatabase():
    uns = Unshortener()
    nuf = NewsURLFilter()
    newsCount = 0
    count = 0
    for key, current in uns.data.data.items():
        print(key + " " + str(current["value"]["status"]))
        unshortedUrl = current["value"]["lastUrl"]
        toPrint = unshortedUrl
        thisIsANews = nuf.isNews(unshortedUrl)
        if thisIsANews:
            toPrint += "\t######## this is a news ########"
            newsCount += 1
        else:
            count += 1
        print(toPrint)
        print()
    print("newsCount=" + str(newsCount))
    print("count=" + str(count))
    print("total=" + str(newsCount + count))
    print("news percent=" + str(newsCount / (newsCount + count) * 100))
    exit()


if __name__ == '__main__':
#     seeUnshortenerDatabase()
    nuf = NewsURLFilter()
    logger = Logger("unshorttao-" + getRandomStr() + ".log")
    uns = Unshortener(logger=logger)
#     dataFiles = sortedGlob(dataDir() + "/TwitterArchiveOrg/Converted3.3/*.bz2")
    dataFiles = sortedGlob(dataDir() + "/TwitterArchiveOrg/Converted2/*.bz2")
    count = 0
    for tweet in JsonReader(dataFiles):
        urls = getNormalizedUrlsFromTweet(tweet)
        for url in urls:
            if uns.isShortener(url):
                result = uns.unshort(url)
                if result["status"] == 200:
                    log("normalized_url: " + url, logger)
                    unshortedUrl = result["lastUrl"]
                    log("unshortedUrl: " + str(unshortedUrl), logger)
                    thisIsANews = nuf.isNews(unshortedUrl)
                    log("thisIsANews: " + str(thisIsANews), logger)
                    if thisIsANews:
                        print("!!!!!!!!!!!!!!!!!!!!!!!!!!")
                    count += 1
                else:
                    log("normalized_url: " + url + " FAILED!", logger)
                    log(listToStr(result), logger)
                log("\n\n-\n\n", logger)
    
    log(str(count), logger)
    uns.close()
    
    
    # On a 50% des shorted urls qui sont des news dans Converted3.3 avec la version isNews de decembre 2017




















