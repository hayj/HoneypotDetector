# coding: utf-8

# pew in webcrawler-venv python ~/wm-dist-tmp/WebCrawler/webcrawler/httpbrowser.py

import requests
from datatools.url import *
from urllib.request import urlopen
from systemtools.basics import *
from systemtools.location import *
from systemtools.logger import *
import requests.auth
from datastructuretools.hashmap import *
from webcrawler.utils import *

def proxyStrToProxyDict(proxyStr):
    theTuple = proxies[i].split(":")
    theDict = {}
    theDict["ip"] = theTuple[0]
    theDict["port"] = theTuple[1]
    if len(theTuple) > 2:
        theDict["user"] = theTuple[2]
    if len(theTuple) > 3:
        theDict["password"] = theTuple[3]
    theDict["type"] = "http"
    return theDict

class HTTPBrowser():
    def __init__ \
    (
        self,
        logger=None,
        verbose=True,
        proxy=None,
        retryIf407=True,
        retryIfTimeout=True,
    ):
        self.retryIfTimeout = retryIfTimeout
        self.retryIf407 = retryIf407
        self.logger = logger
        self.verbose = verbose
        self.proxy = proxy
        self.proxyStr = None
        self.proxyIpStr = None
        if self.proxy is not None and isinstance(proxy, str):
            self.proxy = proxyStrToProxyDict(self.proxy)
        if self.proxy is not None:
            self.proxyStr = "http://" + proxy["ip"] + ":" + proxy["port"]
            self.proxyIpStr = proxy["ip"]
        self.urlParser = URLParser()

    def hasProxy(self):
        return self.proxy is not None

    def getCrawlerName(self):
        return "requests"

    def get(self, url, timeout=20, useProxy=True):
        url = self.urlParser.normalize(url)

        result = \
        {
            "proxy": self.proxyIpStr,
            "lastUrl": None,
            "url": url,
            "historyCount": None,
            "redirected": None,
            "status": None,
            "message": None,
            "html": None,
        }

        response = None
        try:
            if self.hasProxy() and useProxy:
                response = requests.get \
                (
                    url,
                    proxies= \
                    {
                        "http": self.proxyStr,
                        "https": self.proxyStr,
                    },
                    timeout=timeout
                )
            else:
                response = requests.get(url, timeout=timeout)
        except Exception as e:
            errorMessage = "Getting " + url + " error. " + str(e)
            if isinstance(e, requests.exceptions.Timeout):
                errorMessage = "Getting " + url + " timeout. " + str(e)
            logError(errorMessage, self)
            if isinstance(e, requests.exceptions.Timeout) and \
            self.hasProxy() and useProxy and self.retryIfTimeout:
                return self.get(url, timeout=timeout, useProxy=False)
            if "407 Proxy" in str(e) and self.hasProxy() and useProxy and self.retryIf407:
                return self.get(url, timeout=timeout, useProxy=False)
        if response is None:
            result["message"] = errorMessage
            result["status"] = 0
            return result
        else:
            try:
                if response.history:
                    historyCount = 0
                    for _ in response.history:
                        historyCount += 1
                    result["historyCount"] = historyCount
                    result["redirected"] = True
                else:
                    result["historyCount"] = 0
                    result["redirected"] = False
                result["status"] = response.status_code
                result["lastUrl"] = response.url
                result["html"] = response.text
                result["message"] = "ok"
            except Exception as e:
                errorMessage = "Cannot access response attribute " + str(e)
                logError(errorMessage + " " + str(e), self)
                result["message"] = errorMessage

            if result["status"] == 407:
                logError("Failed to connect to the proxy!", self)
            if result["status"] == 407 and self.hasProxy() and useProxy and self.retryIf407:
                return self.get(url, timeout=timeout, useProxy=False)
            else:
                return result


if __name__ == '__main__':
    urls = \
    [
        "http://bit.ly/2AGvbIz",
        "http://httpbin.org/redirect/3",
        "https://api.ipify.org/?format=json",
        "https://www.linkedin.com/?originalSubdomain=fr",
        "http://bit.ly/21vCb1P",
        "http://apprendre-python.com/page-apprendre-variables-debutant-python",
        "www.mon-ip.com/dsfdsgdrfg",
    ]

    for url in urls:
        proxy = None
        if isHostname("datas"):
            proxy = getRandomProxy()
            printLTS(proxy)
        httpBrowser = HTTPBrowser(proxy=proxy, retryIf407=True)
        result = httpBrowser.get(url)
        if dictContains("html", result) and len(result["html"]) > 30:
            result["html"] = result["html"][0:30]
        printLTS(result)

        # TODO test sur datas












