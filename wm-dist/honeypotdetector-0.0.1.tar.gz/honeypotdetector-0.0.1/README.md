# Description

This tool can recognize honeypot urls using selenium to prevent bot detection.

# Dependencies

    pip install ./wm-dist/*.tar.gz