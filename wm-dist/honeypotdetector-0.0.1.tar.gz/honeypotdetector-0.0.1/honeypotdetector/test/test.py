
# coding: utf-8

# pew in honeypotdetector-venv python /home/hayj/Drive/Workspace/Python/Crawling/HoneypotDetector/honeypotdetector/test/test.py


from honeypotdetector.detector import *
from systemtools.logger import *
from datatools.url import *
from datastructuretools.processing import *
from datastructuretools.basics import *
from systemtools.basics import *
import re
from lxml import etree
from io import StringIO, BytesIO
from sklearn import tree
# import urllib.request
# from threading import Lock
# import multiprocessing


if __name__ == '__main__':

    from webcrawler.browser import *
    from webcrawler.utils import *
    print("Start")


#     url = "http://localhost/testajax/honeypot.php"
#     url = "https://www.google.com/search?q=wikipedia"
#     url = "https://www.google.fr/search?q=pytho+list+prepend"
#     url = "https://www.lequipe.fr/Football/Actualites/Nice-pas-la-meme-histoire/845443"
#     url = "https://stackoverflow.com/questions/38060738/python-copy-element"
#     url = sortedGlob("/home/hayj/Workspace/Python/Datasets/TwitterCrawler/twittercrawler/datatest/*.html")[0]
#     url = "file://" + url

    url = "file:///home/hayj/Workspace/Python/Crawling/HoneypotDetector/honeypotdetector/datatest/github.html"


#     b = Browser(ajaxSleep=1.0, proxy=getRandomProxy())
    b = Browser(driverType=DRIVER_TYPE.chrome, ajaxSleep=0.1, proxy=None, headless=False)

    b.setWindowSize(900, 500)
    b.setWindowPosition(5, 500)
    b.html(url)




#     printLTS(b.html(url))
#     page = urllib.request.urlopen(url)
#     strToFile(byteToStr(page.read()), rootPath + "/tmp/" + "no-js-no-comments" + ".html")
#     print(page)



    honeypotDetector = HoneypotDetector()
#     (safeLinks, honeypotLinks) = honeypotDetector.getLinks(b.driver, removeExternal=True, cssSelectorHead="div.ProfileHeaderCard")
    (safeLinks, honeypotLinks) = honeypotDetector.getHref(b.driver, removeExternal=True)
    printLTS(list(safeLinks))
    printLTS(list(honeypotLinks))




    for href in safeLinks:
        print(str(href) + " is supposed a safe link")
        assert honeypotDetector.isHoneypot(href, b.driver) == False
        print("OK")
    for href in honeypotLinks:
        print(str(href) + " is supposed a honeypot link")
        assert honeypotDetector.isHoneypot(href, b.driver) == True
        print("OK")








