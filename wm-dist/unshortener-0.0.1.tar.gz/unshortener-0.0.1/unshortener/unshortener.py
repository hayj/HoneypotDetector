# coding: utf-8

# pew in unshortener-venv python ~/wm-dist-tmp/Unshortener/unshortener/unshortener.py

import requests
from datatools.url import *
from urllib.request import urlopen
from systemtools.basics import *
from systemtools.location import *
from systemtools.logger import *
import requests.auth
from datastructuretools.hashmap import *
from webcrawler.httpbrowser import *
from webcrawler.browser import *
from webcrawler.utils import *
from threading import Thread
import random


class Unshortener():
    """
        Todo option selenium ?
    """
    def __init__(self,
                 logger=None,
                 verbose=True,
                 maxItemCount=100000000,
                 maxDataSizeMo=10000,
                 dataDir=None,
                 seleniumBrowserCount=20,
                 resetBrowsersRate=0.1,
                 useSelenium=False,
                 seleniumBrowsersIsNice=True,
                 storeAll=False,
                 readOnly=False,
                 shortenersDomainsFilePath=None):
        self.readOnly = readOnly
        self.seleniumBrowsersIsNice = seleniumBrowsersIsNice
        self.resetBrowsersRate = resetBrowsersRate
        self.seleniumBrowserCount = seleniumBrowserCount
        self.shortenersDomainsFilePath = shortenersDomainsFilePath
        if self.shortenersDomainsFilePath is None:
            self.shortenersDomainsFilePath = getDataDir() + "/Misc/crawling/shorteners.txt"
        self.useSelenium = useSelenium
        self.storeAll = storeAll
        self.maxDataSizeMo = maxDataSizeMo
        self.maxItemCount = maxItemCount
        self.dataDir = dataDir
        if self.dataDir is None:
            self.dataDir = getDataDir() + "/Misc/crawling/"
        self.fileName = "unshortener-database"
        self.urlParser = URLParser()
        self.requestCounter = 0
        self.verbose = verbose
        self.logger = logger
        self.data = SerializableDict \
        (
            self.dataDir, self.fileName,
            cleanMaxSizeMoReadModifiedOlder=self.maxDataSizeMo,
            cleanMaxValueCountReadModifiedOlder=self.maxItemCount,
            serializeEachNAction=20,
            verbose=True
        )
        self.shortenersDomains = None
        self.initShortenersDomains()
        self.browsers = None
    
    def initShortenersDomains(self):
        if self.shortenersDomains is None:
            shorteners = fileToStrList(self.shortenersDomainsFilePath)
            newShorteners = []
            for current in shorteners:
                current = current.lower()
                newShorteners.append(current)
            shorteners = newShorteners
            self.shortenersDomains = set()
            for current in shorteners:
                newCurrent = self.urlParser.getDomain(current)
                self.shortenersDomains.add(newCurrent)
            self.shortenersDomains = list(self.shortenersDomains)
            # We filter all:
            newShortenersDomains= []
            for current in self.shortenersDomains:
                if "." in current:
                    newShortenersDomains.append(current)
            self.shortenersDomains = newShortenersDomains

    def close(self):
        self.data.close()

    def isShortener(self, url):
        smartDomain = self.urlParser.getDomain(url)
        return smartDomain in self.shortenersDomains

    def isStatusCodeOk(self, statusCode):
        if isinstance(statusCode, dict) and dictContains("statusCode"):
            statusCode = statusCode["statusCode"]
        return statusCode == 200

    def generateSeleniumBrowsers(self):
        # We have to reset browsers sometimes because it can take a lot of RAM:
        if self.browsers is None or getRandomFloat() < self.resetBrowsersRate:
            if self.browsers is not None:
                for browser in self.browsers:
                    browser.quit()
            self.browsers = []
            def generateRandomBrowser(proxy):
                self.browsers.append(Browser(driverType=DRIVER_TYPE.phantomjs, proxy=proxy))
            allThreads = []
            for i in range(self.seleniumBrowserCount):
                theThread = Thread(target=generateRandomBrowser, args=(getRandomProxy(),))
                theThread.start()
                allThreads.append(theThread)
            for theThread in allThreads:
                theThread.join()

    def getRandomSeleniumBrowser(self):
        return random.choice(self.browsers)
    
    def unshort(self, url, force=False, useProxy=True, timeout=20, retryIf407=True):
        """
            force as False will check if the given url have to match with a known shorter service 
        """
        url = self.urlParser.normalize(url)
        smartDomain = self.urlParser.getDomain(url)
        if not force and smartDomain not in self.shortenersDomains:
            result = \
            {
                "force": force,
                "url": url,
                "message": "The domain is not a shortener service!",
                "status": -1,
            }
            return result
        if self.data.hasKey(url):
            log(url + " was in the Unshortener database!", self)
            return self.data.get(url)
        elif self.readOnly:
            result = \
            {
                "force": force,
                "url": url,
                "message": "The url is not in the database and the unshortener was set as read only.",
                "status": -2,
            }
            return result
        else:
            log("Trying to unshort " + url, self)
            proxy = None
            if useProxy:
                proxy = getRandomProxy()
            seleniumFailed = False
            if self.useSelenium:
                self.generateSeleniumBrowsers()
                browser = self.getRandomSeleniumBrowser()
                result = browser.html(url)
                if result["status"] == REQUEST_STATUS.refused or \
                result["status"] == REQUEST_STATUS.timeout:
                    seleniumFailed = True
                    logError("Selenium failed to get " + url + "\nTrying with a HTTPBrowser...", self)
                else:
                    result = convertBrowserResponse(result, browser, nice=self.seleniumBrowsersIsNice)
            if not self.useSelenium or seleniumFailed:
                httpBrowser = HTTPBrowser(proxy=proxy, logger=self.logger, verbose=self.verbose)
                result = httpBrowser.get(url)                
            result["force"] = force
            
            if self.storeAll or result["status"] == 200 or result["status"] == 404:
                self.data.add(url, result)
            del result["html"]
            log("Unshort of " + result["url"] + " : " + str(result["status"]), self)
            return result

def getProxiesPath(proxiesPath=None):
    if proxiesPath is not None:
        return proxiesPath
    else:
        return dataDir() + "/Misc/crawling/proxies-prod.txt"

def getRandomProxy(proxiesPath=None):
    proxiesPath = getProxiesPath(proxiesPath)
    allProxies = getProxies(proxiesPath)
    return random.choice(allProxies)

def getProxies(proxiesPath=None):
    proxiesPath = getProxiesPath(proxiesPath)
    # If the file exist, we parse it, one proxie by line (165.231.108.5:80:user:pass)
    if fileExists(proxiesPath):
        proxies = []
        proxies = fileToStrList(proxiesPath)
        for i in range(len(proxies)):
            theTuple = proxies[i].split(":")
            theDict = {}
            theDict["ip"] = theTuple[0]
            theDict["port"] = theTuple[1]
            theDict["user"] = theTuple[2]
            theDict["password"] = theTuple[3]
            theDict["type"] = "http"
            proxies[i] = theDict
        return proxies
    return None

if __name__ == '__main__':
    uns = Unshortener()
    url = "https://api.ipify.org/?format=json"
#     url = "http://httpbin.org/redirect/3"
    printLTS(uns.unshort(url, force=True))
    

    
    
    